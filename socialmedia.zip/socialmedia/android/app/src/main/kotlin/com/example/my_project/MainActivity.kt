package com.flutterflow.sniffsocial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
