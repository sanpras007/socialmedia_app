import '/flutter_flow/flutter_flow_util.dart';
import 'edit_settings_widget.dart' show EditSettingsWidget;
import 'package:flutter/material.dart';

class EditSettingsModel extends FlutterFlowModel<EditSettingsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
