import '/flutter_flow/flutter_flow_util.dart';
import 'user_list_widget.dart' show UserListWidget;
import 'package:flutter/material.dart';

class UserListModel extends FlutterFlowModel<UserListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
