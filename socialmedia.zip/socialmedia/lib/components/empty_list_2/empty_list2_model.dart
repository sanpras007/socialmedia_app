import '/flutter_flow/flutter_flow_util.dart';
import 'empty_list2_widget.dart' show EmptyList2Widget;
import 'package:flutter/material.dart';

class EmptyList2Model extends FlutterFlowModel<EmptyList2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
