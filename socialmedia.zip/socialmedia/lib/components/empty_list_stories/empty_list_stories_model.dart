import '/flutter_flow/flutter_flow_util.dart';
import 'empty_list_stories_widget.dart' show EmptyListStoriesWidget;
import 'package:flutter/material.dart';

class EmptyListStoriesModel extends FlutterFlowModel<EmptyListStoriesWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
