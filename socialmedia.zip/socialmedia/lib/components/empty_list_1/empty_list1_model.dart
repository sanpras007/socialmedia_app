import '/flutter_flow/flutter_flow_util.dart';
import 'empty_list1_widget.dart' show EmptyList1Widget;
import 'package:flutter/material.dart';

class EmptyList1Model extends FlutterFlowModel<EmptyList1Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
