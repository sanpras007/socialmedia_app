import '/flutter_flow/flutter_flow_util.dart';
import 'create_modal_widget.dart' show CreateModalWidget;
import 'package:flutter/material.dart';

class CreateModalModel extends FlutterFlowModel<CreateModalWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
