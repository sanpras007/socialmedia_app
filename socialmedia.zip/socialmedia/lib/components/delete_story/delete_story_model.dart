import '/flutter_flow/flutter_flow_util.dart';
import 'delete_story_widget.dart' show DeleteStoryWidget;
import 'package:flutter/material.dart';

class DeleteStoryModel extends FlutterFlowModel<DeleteStoryWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
